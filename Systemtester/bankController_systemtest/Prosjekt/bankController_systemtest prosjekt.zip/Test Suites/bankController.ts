<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>bankController</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>75dc8edf-6aa6-4f72-bc84-e5f6d3205cbc</testSuiteGuid>
   <testCaseLink>
      <guid>f35cb044-f23a-48cf-bd80-8e8693d06b0c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/loggInn</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>0bd1001f-bd73-40f2-a319-ab575c288d51</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/hentTransaksjoner</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>d67faf96-bea3-4a2c-8795-3f10c7317c06</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/hentKonti</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>e8c13b96-08b9-4270-95f3-46fa5504fb00</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/hentSaldi</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>bef309d9-3272-4696-bfc6-37d5c2504b35</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/utforBetaling</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>051d1e3a-33f2-4a74-b108-8f430c9fe090</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/registrerBetaling</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>5da3929c-7356-426f-91f7-f0faa79a335a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/hentBetalinger</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>83152311-854a-48ea-9a68-6878f3741564</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/hentKundeInfo</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>319d3137-e025-4cb5-bdfe-7351174318ed</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/bankController/endreKundeInfo</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    